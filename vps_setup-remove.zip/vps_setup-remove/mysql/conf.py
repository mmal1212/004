# conn = mysql.connector.connect

host="188.188.188.188"
user="root"
passwd="passwd@passwd"
port=3306
